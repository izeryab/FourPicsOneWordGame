﻿namespace foursPicsOneWords
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.a1 = new System.Windows.Forms.Label();
            this.a2 = new System.Windows.Forms.Label();
            this.a3 = new System.Windows.Forms.Label();
            this.a4 = new System.Windows.Forms.Label();
            this.ch9 = new System.Windows.Forms.Label();
            this.ch11 = new System.Windows.Forms.Label();
            this.ch12 = new System.Windows.Forms.Label();
            this.ch10 = new System.Windows.Forms.Label();
            this.ch8 = new System.Windows.Forms.Label();
            this.ch7 = new System.Windows.Forms.Label();
            this.ch3 = new System.Windows.Forms.Label();
            this.ch5 = new System.Windows.Forms.Label();
            this.ch6 = new System.Windows.Forms.Label();
            this.ch4 = new System.Windows.Forms.Label();
            this.ch2 = new System.Windows.Forms.Label();
            this.ch1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Label();
            this.level = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.delete = new System.Windows.Forms.PictureBox();
            this.accept = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.delete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // a1
            // 
            this.a1.AutoSize = true;
            this.a1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.a1.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.a1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.a1.Location = new System.Drawing.Point(64, 381);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(41, 40);
            this.a1.TabIndex = 4;
            this.a1.Text = "  ";
            // 
            // a2
            // 
            this.a2.AutoSize = true;
            this.a2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.a2.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.a2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.a2.Location = new System.Drawing.Point(107, 381);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(41, 40);
            this.a2.TabIndex = 5;
            this.a2.Text = "  ";
            // 
            // a3
            // 
            this.a3.AutoSize = true;
            this.a3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.a3.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.a3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.a3.Location = new System.Drawing.Point(150, 381);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(41, 40);
            this.a3.TabIndex = 6;
            this.a3.Text = "  ";
            // 
            // a4
            // 
            this.a4.AutoSize = true;
            this.a4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.a4.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.a4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.a4.Location = new System.Drawing.Point(193, 381);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(41, 40);
            this.a4.TabIndex = 7;
            this.a4.Text = "  ";
            // 
            // ch9
            // 
            this.ch9.AutoSize = true;
            this.ch9.BackColor = System.Drawing.Color.White;
            this.ch9.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch9.ForeColor = System.Drawing.Color.Black;
            this.ch9.Location = new System.Drawing.Point(94, 491);
            this.ch9.Name = "ch9";
            this.ch9.Size = new System.Drawing.Size(37, 40);
            this.ch9.TabIndex = 21;
            this.ch9.Text = "X";
            this.ch9.Click += new System.EventHandler(this.ch9_Click);
            // 
            // ch11
            // 
            this.ch11.AutoSize = true;
            this.ch11.BackColor = System.Drawing.Color.White;
            this.ch11.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch11.ForeColor = System.Drawing.Color.Black;
            this.ch11.Location = new System.Drawing.Point(180, 491);
            this.ch11.Name = "ch11";
            this.ch11.Size = new System.Drawing.Size(37, 40);
            this.ch11.TabIndex = 20;
            this.ch11.Text = "X";
            this.ch11.Click += new System.EventHandler(this.ch11_Click);
            // 
            // ch12
            // 
            this.ch12.AutoSize = true;
            this.ch12.BackColor = System.Drawing.Color.White;
            this.ch12.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch12.ForeColor = System.Drawing.Color.Black;
            this.ch12.Location = new System.Drawing.Point(223, 491);
            this.ch12.Name = "ch12";
            this.ch12.Size = new System.Drawing.Size(37, 40);
            this.ch12.TabIndex = 19;
            this.ch12.Text = "X";
            this.ch12.Click += new System.EventHandler(this.ch12_Click);
            // 
            // ch10
            // 
            this.ch10.AutoSize = true;
            this.ch10.BackColor = System.Drawing.Color.White;
            this.ch10.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch10.ForeColor = System.Drawing.Color.Black;
            this.ch10.Location = new System.Drawing.Point(137, 491);
            this.ch10.Name = "ch10";
            this.ch10.Size = new System.Drawing.Size(37, 40);
            this.ch10.TabIndex = 18;
            this.ch10.Text = "X";
            this.ch10.Click += new System.EventHandler(this.ch10_Click);
            // 
            // ch8
            // 
            this.ch8.AutoSize = true;
            this.ch8.BackColor = System.Drawing.Color.White;
            this.ch8.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch8.ForeColor = System.Drawing.Color.Black;
            this.ch8.Location = new System.Drawing.Point(51, 491);
            this.ch8.Name = "ch8";
            this.ch8.Size = new System.Drawing.Size(37, 40);
            this.ch8.TabIndex = 17;
            this.ch8.Text = "X";
            this.ch8.Click += new System.EventHandler(this.ch8_Click);
            // 
            // ch7
            // 
            this.ch7.AutoSize = true;
            this.ch7.BackColor = System.Drawing.Color.White;
            this.ch7.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch7.ForeColor = System.Drawing.Color.Black;
            this.ch7.Location = new System.Drawing.Point(8, 491);
            this.ch7.Name = "ch7";
            this.ch7.Size = new System.Drawing.Size(37, 40);
            this.ch7.TabIndex = 16;
            this.ch7.Text = "X";
            this.ch7.Click += new System.EventHandler(this.ch7_Click);
            // 
            // ch3
            // 
            this.ch3.AutoSize = true;
            this.ch3.BackColor = System.Drawing.Color.White;
            this.ch3.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch3.ForeColor = System.Drawing.Color.Black;
            this.ch3.Location = new System.Drawing.Point(94, 442);
            this.ch3.Name = "ch3";
            this.ch3.Size = new System.Drawing.Size(37, 40);
            this.ch3.TabIndex = 27;
            this.ch3.Text = "X";
            this.ch3.Click += new System.EventHandler(this.ch3_Click);
            // 
            // ch5
            // 
            this.ch5.AutoSize = true;
            this.ch5.BackColor = System.Drawing.Color.White;
            this.ch5.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch5.ForeColor = System.Drawing.Color.Black;
            this.ch5.Location = new System.Drawing.Point(180, 442);
            this.ch5.Name = "ch5";
            this.ch5.Size = new System.Drawing.Size(37, 40);
            this.ch5.TabIndex = 26;
            this.ch5.Text = "X";
            this.ch5.Click += new System.EventHandler(this.ch5_Click);
            // 
            // ch6
            // 
            this.ch6.AutoSize = true;
            this.ch6.BackColor = System.Drawing.Color.White;
            this.ch6.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch6.ForeColor = System.Drawing.Color.Black;
            this.ch6.Location = new System.Drawing.Point(223, 442);
            this.ch6.Name = "ch6";
            this.ch6.Size = new System.Drawing.Size(37, 40);
            this.ch6.TabIndex = 25;
            this.ch6.Text = "X";
            this.ch6.Click += new System.EventHandler(this.ch6_Click);
            // 
            // ch4
            // 
            this.ch4.AutoSize = true;
            this.ch4.BackColor = System.Drawing.Color.White;
            this.ch4.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch4.ForeColor = System.Drawing.Color.Black;
            this.ch4.Location = new System.Drawing.Point(137, 442);
            this.ch4.Name = "ch4";
            this.ch4.Size = new System.Drawing.Size(37, 40);
            this.ch4.TabIndex = 24;
            this.ch4.Text = "X";
            this.ch4.Click += new System.EventHandler(this.ch4_Click);
            // 
            // ch2
            // 
            this.ch2.AutoSize = true;
            this.ch2.BackColor = System.Drawing.Color.White;
            this.ch2.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch2.ForeColor = System.Drawing.Color.Black;
            this.ch2.Location = new System.Drawing.Point(51, 442);
            this.ch2.Name = "ch2";
            this.ch2.Size = new System.Drawing.Size(37, 40);
            this.ch2.TabIndex = 23;
            this.ch2.Text = "X";
            this.ch2.Click += new System.EventHandler(this.ch2_Click);
            // 
            // ch1
            // 
            this.ch1.AutoSize = true;
            this.ch1.BackColor = System.Drawing.Color.White;
            this.ch1.Font = new System.Drawing.Font("Miriam Transparent", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.ch1.ForeColor = System.Drawing.Color.Black;
            this.ch1.Location = new System.Drawing.Point(8, 442);
            this.ch1.Name = "ch1";
            this.ch1.Size = new System.Drawing.Size(37, 40);
            this.ch1.TabIndex = 22;
            this.ch1.Text = "X";
            this.ch1.Click += new System.EventHandler(this.ch1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Miriam Transparent", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(159, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 30);
            this.label1.TabIndex = 30;
            this.label1.Text = "LEVEL #";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Miriam Transparent", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(5, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 30);
            this.label2.TabIndex = 31;
            this.label2.Text = "Time :";
            // 
            // timer
            // 
            this.timer.AutoSize = true;
            this.timer.BackColor = System.Drawing.Color.White;
            this.timer.Font = new System.Drawing.Font("Miriam Transparent", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.timer.ForeColor = System.Drawing.Color.Black;
            this.timer.Location = new System.Drawing.Point(95, 19);
            this.timer.Name = "timer";
            this.timer.Size = new System.Drawing.Size(58, 30);
            this.timer.TabIndex = 32;
            this.timer.Text = "120";
            // 
            // level
            // 
            this.level.AutoSize = true;
            this.level.BackColor = System.Drawing.Color.White;
            this.level.Font = new System.Drawing.Font("Miriam Transparent", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.level.ForeColor = System.Drawing.Color.Black;
            this.level.Location = new System.Drawing.Point(272, 19);
            this.level.Name = "level";
            this.level.Size = new System.Drawing.Size(28, 30);
            this.level.TabIndex = 33;
            this.level.Text = "1";
            // 
            // timer1
            // 
            this.timer1.Interval = 600;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // delete
            // 
            this.delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.delete.Image = global::foursPicsOneWords.Properties.Resources.delete;
            this.delete.Location = new System.Drawing.Point(266, 491);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(37, 40);
            this.delete.TabIndex = 29;
            this.delete.TabStop = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // accept
            // 
            this.accept.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.accept.Image = global::foursPicsOneWords.Properties.Resources.Accept;
            this.accept.ImageLocation = "";
            this.accept.Location = new System.Drawing.Point(266, 442);
            this.accept.Name = "accept";
            this.accept.Size = new System.Drawing.Size(37, 40);
            this.accept.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.accept.TabIndex = 28;
            this.accept.TabStop = false;
            this.accept.Click += new System.EventHandler(this.accept_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::foursPicsOneWords.Properties.Resources.Level11;
            this.pictureBox1.Location = new System.Drawing.Point(4, 64);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(307, 302);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(315, 552);
            this.Controls.Add(this.level);
            this.Controls.Add(this.timer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.accept);
            this.Controls.Add(this.ch3);
            this.Controls.Add(this.ch5);
            this.Controls.Add(this.ch6);
            this.Controls.Add(this.ch4);
            this.Controls.Add(this.ch2);
            this.Controls.Add(this.ch1);
            this.Controls.Add(this.ch9);
            this.Controls.Add(this.ch11);
            this.Controls.Add(this.ch12);
            this.Controls.Add(this.ch10);
            this.Controls.Add(this.ch8);
            this.Controls.Add(this.ch7);
            this.Controls.Add(this.a4);
            this.Controls.Add(this.a3);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.delete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label a1;
        private System.Windows.Forms.Label a2;
        private System.Windows.Forms.Label a3;
        private System.Windows.Forms.Label a4;
        private System.Windows.Forms.Label ch9;
        private System.Windows.Forms.Label ch11;
        private System.Windows.Forms.Label ch12;
        private System.Windows.Forms.Label ch10;
        private System.Windows.Forms.Label ch8;
        private System.Windows.Forms.Label ch7;
        private System.Windows.Forms.Label ch3;
        private System.Windows.Forms.Label ch5;
        private System.Windows.Forms.Label ch6;
        private System.Windows.Forms.Label ch4;
        private System.Windows.Forms.Label ch2;
        private System.Windows.Forms.Label ch1;
        private System.Windows.Forms.PictureBox accept;
        private System.Windows.Forms.PictureBox delete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label timer;
        private System.Windows.Forms.Label level;
        private System.Windows.Forms.Timer timer1;
    }
}

